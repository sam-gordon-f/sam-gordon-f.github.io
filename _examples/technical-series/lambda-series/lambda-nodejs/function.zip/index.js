require('cfn-response')

  // code entry point
exports.handler = (event, context, callback) => {
  
    // code return point
  callback(null, {
    status: true
  });
};
